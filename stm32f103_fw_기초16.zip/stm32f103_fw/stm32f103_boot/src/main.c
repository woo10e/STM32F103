/*
 * main.c
 *
 *  Created on: Mar 29, 2022
 *      Author: uylee
 */


#include "main.h"




int main(void)
{
  hwInit();
  apInit();

  apMain();
  /*test*/

  return 0;
}
