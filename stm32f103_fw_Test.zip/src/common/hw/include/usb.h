/*
 * usb.h
 *
 *  Created on: 2020. 12. 9.
 *      Author: baram
 */

#ifndef SRC_COMMON_HW_INCLUDE_USB_H_
#define SRC_COMMON_HW_INCLUDE_USB_H_


#include "hw_def.h"


#ifdef _USE_HW_USB


bool usbInit(void);


#endif

#endif /* SRC_COMMON_HW_INCLUDE_USB_H_ */
