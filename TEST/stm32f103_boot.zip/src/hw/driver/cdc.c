/*
 * cdc.c
 *
 *  Created on: 2020. 12. 11.
 *      Author: baram
 */


#include "cdc.h"





bool cdcInit(void)
{
  bool ret = true;


  return ret;
}
