/*
 * ap.h
 *
 *  Created on: Mar 29, 2022
 *      Author: uylee
 */

#ifndef SRC_AP_AP_H_
#define SRC_AP_AP_H_

#include "hw.h"

void apInit(void);
void apMain(void);

#endif /* SRC_AP_AP_H_ */
