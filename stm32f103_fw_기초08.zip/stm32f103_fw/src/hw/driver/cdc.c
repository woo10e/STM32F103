/*
 * cdc.c
 *
 *  Created on: 2022. 3. 31.
 *      Author: uylee
 */


#include "cdc.h"

bool cdcInit(void)
{
  bool ret = true;

  return ret;
}
